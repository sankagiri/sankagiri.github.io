# DA5453 Module 2 Coding Assignment — Provisional preview

This folder contains a provisional preview of the Module 2 coding assignment for
**DA5453: Learning from Human Preferences**.

The preview is intended to show the structure, concepts, and approximate workload of the
assignment. The dataset, model specification, numerical results, and some questions will
be revised before the final assignment is released.

## Files for students

- `DA5453_M2_assignment_preview.ipynb` — the student notebook
- `DA5453_M2_assignment_instructions.md` — brief instructions
- `train.csv` and `train_balanced.csv` — training data
- `eval_1.csv`, `eval_2.csv`, and `eval_3.csv` — evaluation data
- `answers.csv` — data for the controlled diagnostic

## Running the notebook

1. Download and extract `DA5453_M2_assignment_preview.zip`.
2. Open `DA5453_M2_assignment_preview.ipynb` in Google Colab.
3. Upload the six CSV files through the Colab file panel.
4. Run the cells in order.

This code should easily run on most laptops. 
You can also try using Google Colab.
The free Colab CPU runtime is sufficient. No GPU is required.
