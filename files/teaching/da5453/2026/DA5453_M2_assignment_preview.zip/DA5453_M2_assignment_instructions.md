# DA5453 Module 2 Coding Assignment — Provisional preview

**Course:** Learning from Human Preferences  
**Instructor:** Suryanarayana Sankagiri

> **Provisional preview.** This notebook illustrates the expected structure, concepts,
> and approximate workload of the Module 2 coding assignment. The dataset, model specification, numerical
> results, and some questions will be revised before the final assignment is released.

## Purpose

In this assignment, you will train a reward model from pairwise preference data. You will
then test the model, identify a shortcut that it has learnt, and repair it.

No previous knowledge of language models, text embeddings, or PyTorch is assumed. The
notebook contains short tutorials on these topics.

## Files

Keep the following files in the same folder:

- `DA5453_M2_assignment_preview.ipynb`
- `train.csv`
- `train_balanced.csv`
- `eval_1.csv`
- `eval_2.csv`
- `eval_3.csv`
- `answers.csv`

## Main tasks

1. Run the embedding tutorial and comment briefly on the similarity and PCA plots.
2. Implement the Bradley–Terry reward-model loss and training loop.
3. Evaluate the model and interpret its performance on three evaluation sets.
4. Measure the effect of answer style and answer relevance separately.
5. Add prompt–response interaction features and identify a robust configuration.

The notebook supplies the data loading, embedding model, plotting code, and experiment
harness. Cells marked **TODO** are to be completed by the student.

## Computing requirements

The notebook is designed for Google Colab. The free CPU runtime is sufficient. A GPU is
not required.

## Submission

No submission is required for this preview. The final assignment will specify the exact
submission format, deadline, and mark distribution.
